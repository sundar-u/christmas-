# christmas-tree

A christmas tree animation with HTML and CSS.

## Resources used in this project

- [Icons](https://favicon.io/emoji-favicons/christmas-tree/)
- [Font](https://fonts.google.com/specimen/Berkshire+Swash)
- [Light ropes](https://codepen.io/tobyj/pen/QjvEex)
- [Gradient background](https://mycolor.space/gradient3)
- [Gifts](https://codepen.io/lenasta92579651/pen/xxERxBx)
- [Countdown timer](https://github.com/PButcher/flipdown#flipdown)
- [Flying santa](https://codepen.io/Coding-Artist/pen/ExaXZqZ)
- [Santa's Reindeer](https://codepen.io/ivanodintsov/pen/BjVMRL)
